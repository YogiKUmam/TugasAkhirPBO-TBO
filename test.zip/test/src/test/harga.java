/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Yogie
 */
abstract class harga {
    private int harga = 150000;
    public abstract double Cekbiaya();
    
    public double harga(int harga){
      harga = harga * 1;
      return harga;
  }
}
