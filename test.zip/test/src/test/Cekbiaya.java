/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Yogie
 */
public class Cekbiaya extends harga{
  double harga = 150000;
  double Cekbiaya;
  
   public double harga(int harga){
      harga = 150000 * 1;
      return Cekbiaya;
  }
  public double harga(Double harga){
      harga = Double.valueOf(harga);
      return Cekbiaya;
  }
  
  @Override
  public double Cekbiaya(){
      Cekbiaya = harga;
      return Cekbiaya;
  }
}
        