/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Yogie
 */
public class IdPassword {
    //mutator method
    String getIdAdmin(){
    String idAdmin = "admin";
        return idAdmin;
        
    }
    
    String getPwAdmin(){
        String pwAdmin = "admin123";
        return pwAdmin;
    }

    String getIdUser(){
        String idUser = "user";
        return idUser;
        
    }
    
    String getPwUser(){
        String pwUser = "user123";
        return pwUser;
    }
}
